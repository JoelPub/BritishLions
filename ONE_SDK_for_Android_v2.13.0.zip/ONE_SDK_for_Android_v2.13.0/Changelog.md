Version 2.13.0
 	- [NEW] Improve install/identity tracking to allow identity sync with web touchpoints programmatically.
 	- [NEW] Added a watchdog service which listens for boot events to allow for push notifications to be displayed even after an app has been terminated. This will only run if push notifications have been enabled.
 	- [NEW] Ability to capture text from a Button.
 	- [UPDATE] Updated the one-install implementations to not send this interaction for SDK updates.
 	- [UPDATE] Updated all the SDK dependecies to the latest available version. See the integration document for further details.
 	- [UPDATE] Improve the application state tracking in Admin mode to avoid bugs when editting interaction names.
 	- [UPDATE] Added imrpovements to how the interaction response is retrieved.
 	- [BUGFIX] Resolved an Android O issues where the Admin mode highlighting was not covering the whole screen.
 	- [BUGFIX] Resolved an issue where decalred whitelist and blacklist links didn't fully work as expected.
 	- [BUGFIX] Fixed a memory leak which was occuring when running the Android SDK in Preview Mode.
 	- [BUGFIX] Fixed how properties stored in cache are retrieved to ensure the implementation works with React Native implementations. 

Version 2.12.0
	- [NEW] Ability to whitelist links eligible for identity transfer.
	- [NEW] Ability to blacklist links not eligible for identity transfer.
	- [BUGFIX] Resolved an issue where the Admin mode poker chip would not appear on screen when a proxy was used.
	- [BUGFIX] Resolved an issue where LeakCanary was interfering with the push notification implementation.
	- [BUGFIX] Resolved an issue where the poker chip disappeared when re-logging after 'Session Expired' alert was presented.
	- [BUGFIX] Resolved networking queuing issues which could lead to OOM when multiple 401 or a connection can not fully be established.
	- [BUGFIX] Moved all network code on another thread to avoid StrictMode policy violation errors.
	
Version 2.11.0
    - [NEW] Ability to codelessly send a push token.
    - [NEW] Ability to codelessly show push notifications.
    - [NEW] Codeless push message tracking on receival and open. 
    - [NEW] Ability to codelessly open deep link passed on a push notification.
    - [NEW] Added SDK proguard rules so that the codeless SDK can run in apps which have proguard enabled. 
    - [NEW] Ability to track installs using ONE pixel tracking URL. 
    - [UPDATE] Updated the properties caching logic to stop sending invalid properties after 2 failed attempts.
    - [BUGFIX] Resolved a crash that was occurring when integrating the SDK with React Native apps which use a ViewPager. 

Version 2.10.0
	- [NEW] Ability to select any elements visible on screen and interactions if no element is found on tap, in Admin mode. 
	- [NEW] Ability to retrieve the push token passed to the SDK.
	- [BUGFIX] Resolved an issue where the Preview panel could end up showing the incorrect number of points. 
	- [BUGFIX] Resolved an issue where the "Group" tab was disappearing in the Admin popover after a rotation event. 
	- [BUGFIX] Added a fix to ensure "about:blank" schemes are processed when the codeless identity transfer and link tracking is used. Also we have improved the uri processing by wrapping it into a try-catch block to prevent crashes from occurring.
	- [BUGFIX] Added null check support for the childFragment manager to prevent NPE traces during fragments parsing.
	- [BUGIFX] Fixed various leaks identified under Admin mode.
	- [BUGFIX] Resolved a cast exception triggered when apps use a Navigation Listener.
	- [BUGFIX] Resolved a crash which could be experienced when the SDK would run in Admin mode.
    - [BUGFIX] Resolved an issue where the poker chip would appear in other apps if the current app was loading a request and the app context was switched.
	- [BUGFIX] Fixed an Admin mode issue where the poker chip would appear on screen during request loads, leading to unexpected behaviour. 
	- [BUGFIX] Fixed an Admin mode issue where the highlighting wasn’t shown after returning from another app. 
	- [BUGFIX] Resolved an Admin mode issue where the ‘Remember Me’ toggle logic was functioning incorrectly. 
	- [BUGFIX] Fixed an Admin mode issue where the highlighting was still showing after an error message was displayed.

Version 2.9.0
	- [NEW] Cross-channel and install tracking using Chrome in apps running on Android 4.0.3.
	- [UPDATE] The SDK now stores the thunderhead anonymous identifier depending on the space to which an app belongs to.
	- [UPDATE] Updated the SDK to use the Android compile SDK version 25, build tools version 25.0.1, target SDK version to 25 and support library to 25.0.1.
	- [UPDATE] Updated the View Pager tracking API to better track child views added and removed from a View Pager.
	- [BUGFIX] Resolved attributes list incompatibility with the new design time api.

Version 2.8.0
	- [NEW] Ability to automatically append a one-tid parameter to http/https links opened from an app to support identity transfer across channels. This feature is achieved using AspectJ.
	- [NEW] Ability to automatically send one click interaction to support attribution tracking. This feature is achieved using AspectJ.
	- [BUGFIX] Resolved an issue where the poker chip appears in other apps during an Admin mode login session.
	- [BUGFIX] Resolved an issue where the loading dialog was showing endlessly after the no internet connection error appeared in Admin mode. 
	- [BUGFIX] Fixed a crash which was happening in Admin mode if switching to another app whilst data was being retrieved. 
	- [BUGFIX] Resolved an issue where the poker chip would become invisible after a network error would occur in Admin mode, in certain apps. 
	- [BUGFIX] Resolved an issue where java.lang.NoSuchFieldException would appear if an app was using nested fragments on an API version lower than 21.
	- [BUGIFX] Fixed an issue where some methods would still send runtime data to ONE in Admin mode. 
	- [BUGFIX] Resolved an issue where the region popover was not fully displayed on Android 7. 
	- [BUGFIX] Fixed an Admin mode crash which was occurring on device rotation.
	- [BUGFIX] Resolved several memory leaks which were occurring when running the app in Admin mode.  

Version 2.7.6
	- [BUGFIX] Removed support for android.support.v4.widget.DrawerLayout.

Version 2.7.5
	- [UPDATE] Added codeless tracking and capture point support for Sticky Header List Views. 
	- [BUGFIX] Resolved an issue where the application underlying interaction blocked the UI.
	- [BUGFIX] Resolved an issue where highlighting was not working as expected in Admin mode when the keyboard was up. 
	- [BUGFIX] Resolved a crash that was occurring in Admin mode if the credentials where not available.
	- [BUGFIX] Resolved an issue where alert messaged could appear unexpectedly on top of the Admin mode popover. 
	- [BUGFIX] Resolved an Admin mode issue where the poker chip would end up in an incorrect state. 
	- [BUGFIX] Resolved an issue where action bar items were not highlighted correctly in some apps.

Version 2.7.4
	- [UPDATE] Updated the overlapping elements in cells algorithm to better deal with cases where multiple elements sit on top of each other and require Admin mode access. 
	- [UPDATED] Updated the List, Grid and Recycler view data capture algorithms to resolve several data capture bugs observed during a recent integration.
	- [BUGFIX] Resolved an User mode bug where the tid was not persisted after an app was terminated.
	- [BUGFIX] Resolved an Admin mode bug where the popover was not being presented correctly on screen.
	- [BUGFIX] Resolved a crash which was occurring in apps using a particular type of scroll implementation.
	- [BUGFIX] Resolved an issue which was preventing Admin users from logging in.
	- [BUGFIX] Resolved an issue where the action bar was not correctly highlighted in Admin mode. 
	- [BUGFIX] Resolved an issue where the tab bars in some apps where not correctly recognised by the SDK.
	- [BUGFIX] Resolved an issue where an Admin user was unable to select navigation drawers items.
	- [BUGFIX] Resolved a crash which was occurring sometimes in Admin mode when the device was rotated.
	- [BUGFIX] Resolved an issue where the Admin mode window was disappearing on device rotation.

Version 2.7.3
	- [NEW] Ability to send a push token to ONE. This feature simply exposes the ability to programmatically pass the push token to ONE and will become available as an engagement feature in future ONE releases.
	- [UPDATE] Ability to call the SDK public methods from any thread.
	- [UPDATE] Ability to capture/tracking views from toolbar and action bar.
	- [BUGFIX] Resolved an issue where the SDK could crash when switching from Admin to Preview mode.
	- [BUGFIX] Resolved an issue where the Admin mode poker chip was displayed incorrectly in the app.
	- [BUGFIX] Resolved an issue where the Admin popover was shown incorrectly on screen. 
	- [BUGFIX] Resolved an issue where the keyboard was not hidden when the poker chip was tapped, when running the SDK in Admin mode.

Version 2.7.2
	- [NEW] Ability to track list items where the label matches the list item width and height.
	- [NEW] Ability to send a 'one-click' interaction to ONE for outbound links.
	- [UPDATE] Added the clearUserProfile method as part of the queued requests.
	- [BUGFIX] Resolved an issue where the the group highlighting wasn’t working correctly when deleting group tracking or capture points on Android 4.1.
	- [BUGFIX] Resolved an issue where the Admin mode region popover could end up in an empty state.
	- [BUGFIX] Resolved an issue where Admin popover was incorrectly positioned in some apps.
	- [BUGFIX] Resolved an issue where the incorrect dialog style was being used, in some apps, when running the SDK in Admin mode.

Version 2.7.1
	- [NEW] Ability to store username and passwords securely on the device for Admin mode, in order to allow easy access back once a session expires. 
	- [UPDATE] Allow developers to pass a URI object into getUriWithOneTid, to enable identity transfer when the Android Uri API is used. 
	- [BUGFIX] Resolved an issue where the mini notification was still visible after leaving an interaction.
	- [BUGFIX] Resolved an issue where the poker chip remained active when the app lost connectivity and the authentication session expired. 
	- [BUGFIX] Resolved an issue where manually triggered interactions were not correctly queued. 
	- [BUGFIX] Resolved an issue where the tid was not correctly saved. 

Version 2.7.0
	- [NEW] Ability to send capture point request prior to tracking point request for recycler views. This helps the SDK align with ONE’s dynamic proposition requirements.
	- [NEW] Ability to enter preview mode on long press.
	- [UPDATE] Updated the getURLWithOneTid method to only update the ‘one-tid’ parameter value should this already exist in the URL provided.
	- [UPDATE] When running the SDK in User mode, view hierarchies will only be automatically traversed if tracking or capture points are returned for an interaction request. 
	- [UPDATE] Improved the Preview mode TID view to be automatically updated when a new TID is received should the Preview panel be already opened. 
	- [BUGFIX] Fixed an issue where the poker chip could disappear on device rotation. 
	- [BUGFIX] Resolved an issue where properties sent using the SDK public methods, were not sent when running the SDK in Preview mode. 
	- [BUGFIX] Resolved rotation issues which were causing the Admin popover to be incorrectly displayed under certain circumstances. 
	- [BUGFIX] Resolved an issue where the Admin popover was positioned incorrectly on screen.
	- [BUGFIX] Fixed rotation issues in the tracking and capture views.	
	- [BUGFIX] Resolved an issue where the optimization could appear in Admin mode.

Version 2.6.0
	- [NEW] Added support for automatic incoming parameter capture - the SDK will now send any parameters passed on a deep link to a ONE base touchpoint.
	- [NEW] Added support for outgoing one-tid parameter, for identity transfer, using a public method.
	- [NEW] Added support for automatic data capture in recycler views on load and on scroll
	- [NEW] Added ability to see the current TID in preview mode.
	- [NEW] Added ability to generate a monitor TID link and share this in preview mode.
	- [UPDATE] Extended the SDKs programmatic support to allow response retrieval from manually triggered interactions with properties.
	- [UPDATE] Aligned the poker chip logic with the iOS implementation.
	- [UPDATE] Added further guards against the SDK crashing an app, in case some values are null. 
	- [BUGFIX] Resolved an issue where TID was not saved correctly in some instances. 
	- [BUGFIX] Resolved an issue where incorrect data was automatically captured when scrolling list really fast. 
	- [BUGFIX] Resolved an issue where the automatic capture cache was not functioning correctly. 
	- [BUGFIX] Resolved an issue where untracked elements were incorrectly highlighted on some devices.
	- [BUGFIX] Resolved an issue where an error was shown when creating a new attribute with a name that already exists. 
	- [BUGFIX] Resolved an issue where response codes where not sent to a base interaction. 
	- [BUGFIX] Resolved an issue where single tracking events were not sent for radio buttons which sat within list items. 

Version 2.5.0
	- [NEW] Added support for UTF-8 in mobile assets.
	- [NEW] Added support for CSRF headers to all design time APIs.
	- [NEW] Added ability to track and capture data from repeating list/grid view lists items and list item elements in both User and Admin mode using groups.
	- [UPDATE] Updated the list and grid view data capture algorithms to send captured data on click of a list item. This helps align the implementation with ONE’s dynamic proposition requirements. 
	- [UPDATE] Disabled retry on failure for network requests. 
	- [UPDATE] Improved several areas of the SDK based on static analysis feedback.
	- [BUGFIX] Resolved an issue where the poker chip would remain on screen if the app was exited once connectivity was lost. 
	- [BUGFIX] Resolved an issue where the submit button was not functioning correctly in some of the Admin mode views.
	- [BUGFIX] Resolved a crash which was happening in apps using a Navigation Drawer.
	- [BUGFIX] Fixed a null pointer exception inside the NetworkErrorHandler.
	- [BUGFIX] Added a catch for out of memory exceptions in the case there is not enough memory to decode an asset image returned from a mini or full screen optimization. 
	- [BUGFIX] Resolved an issue where an empty alert was sometimes shown when adding capture or tracking point in Admin mode. 
	- [BUGFIX] Resolved an issue where the data attribute item was switched to another one when searching in Admin mode. 
	- [BUGFIX] Resolved an issue where the key icon was not being displayed on the capture point main screen in Admin mode. 
	- [BUGFIX] Resolved an issue where data was not being sent in User mode for buttons and cells contained within a toolbar. 

Version 2.4.0
	- [NEW] Ability to set a mini notification background colour.
	- [NEW] Removed single Customer Key and added support capturing into Key attributes.
	- [NEW] Ability to set a mini notification timer.
	- [NEW] Ability to set a mini notification text size and colour.
	- [NEW] Added support for flexible image width in mini notifications.
	- [NEW] Ability to send a response code programmatically.
	- [NEW] Ability to switch off automatic interaction detection in the SDK.
	- [NEW] Ability to select attributes as dynamic propositions.
	- [NEW] Support for programmatically triggering interaction requests, for another channel, from within a current mobile touchpoint.
	- [NEW] Added support for retrofit 2. 
	- [UPDATE] Updated the path generation algorithm to contain layout details. 
	- [BUGFIX] Resolved a null pointer exception thrown by the NetworkErrorHandler. 
	- [BUGFIX] Resolve an issue where the mini notification was partly hidden.
	- [BUGFIX] Fixed an issue where white spaces were not trimmed for capture points and data attribute names.
	- [BUGFIX] Resolved an issue where the incorrect colour of the proposition and activity type name was used in Admin mode. 
	- [BUGFIX] Resolved an issue where the incorrect colour was used for the selection tick marker. 
	- [BUGFIX] Resolved an issue where an appropriate error message wasn’t shown when the list of attributes could not be retrieved.
	- [BUGFIX] Resolved an issue where the search field is not available after pressing the hardware back button.
	- [BUGFIX] Resolved an issue where some labels where incorrectly placed in the Data Attribute screen
	- [BUGFIX] Resolved an issue where multiple preview panels were shown after launching the app for the first time
	- [BUGFIX] Resolved an issue where the search box close button was incorrectly placed
	- [BUGFIX] Resolved an issue where the 'No results found' label was not visible in some cases where no data was available in the lists
	- [BUGFIX] Resolved an issue where the app used to crash when running the stress testing on the Proposition list view
	- [BUGFIX] Resolved an issue where the incorrect placeholder was used for the activity search field
	- [BUGFIX] Resolved an issue where pressing the hardware back button didn’t fully return the user to the initial state
	- [BUGFIX] Resolved an issue where the cursor did’t focus on the search field when navigating through proposition levels
	- [BUGFIX] Resolved an issue where 'Create new attribute' button is visible when searching


Version 2.3.1
	- [BUGFIX] Resolved 401 responses for design time request.

Version 2.3.0
	- [NEW] Extended SDKs programmatic support to allow response retrieval from manually triggered interactions.
	- [NEW] Ability to search attribute, activity and proposition lists.
	- [UPDATE] Added support for tracking expandable lists and spinner lists.
	- [BUGFIX] Fixed an issue where Popup Menu Android element was highlighted in orange but couldn’t be tracked.
	- [BUGFIX] Fixed an issue where switching between the element and region tabs in the Admin popover caused the app to crash.
	- [BUGFIX] Resolved issue where an Admin user could open multiple Proposition lists.
	- [BUGFIX] Resolved issue where some list dividers where not being shown in Android 6.0.
	- [BUGFIX] Resolved issue where region popover would sometimes be shown off screen.
	- [BUGFIX] Resolved issue where optimization would interfere with the preview panel.
	- [BUGFIX] Fixed multiple preview panels appearing on poker chip tap.
	- [BUGFIX] Resolved an issue where the optimization point list was cleared when editing the region name.
	- [BUGFIX] Resolved an issue where a black screen sometimes would appear when edit mode was on.
	- [BUGFIX] Resolved an issue where the region tracking point counter didn’t decrease when deleting a tracking point.

Version 2.2.0
	- [NEW] Ability to add multiple tracking points in Admin mode.
	- [NEW] Ability to see optimization points in the Admin popover.
	- [NEW] Ability to auto-recognise top most region on a screen.
	- [UPDATE] Updated Preview mode UI to align with new Tagger.
	- [UPDATE] Updated Edit mode Admin popover to align with new Tagger.
	- [UPDATE] Updated Edit mode highlighting to align with new Tagger.
	- [BUGFIX] Resolved an issue where the optimization point options were shown under the element section.
	- [BUGFIX] Fixed Preview mode issue where selecting the current release didn’t send a new interaction request.
	- [BUGFIX] Fixed date capturing for API 21 by adding additional listeners.
	- [BUGFIX] Fixed a crash which was occurring sometimes when renaming a region.
	- [BUGFIX] Fixed a crash which was occurring sometimes when deleting a point.
	- [BUGFIX] Fixed an issue where Admin mode highlighting wasn’t working properly when deleting a point.
	- [BUGFIX] Fixed an issue where long pressing the poker chip would enter an edit mode state with preview still active.
	- [BUGFIX] Resolved crash which was occurring sometimes in the list of data attributes.
	- [BUGFIX] Fixed bug which led to multiple propositions and activity types to appear to be selected in a list.
	- [BUGFIX] Resolved an issue where the SDK sent unidentified capture points to ONE in certain apps.
	- [BUGFIX] Fixed an issue where the click event tracking was not properly functioning on RecyclerView element.
	- [BUGFIX] Fixed issue where an user was unable to click the Exit button in Preview mode.
	- [BUGFIX] Fixed an issue where a notification is still shown after exiting Preview mode.

Version 2.1.0
	- [NEW] Ability to preview in the works.
	- [NEW] Ability to preview multiple releases.
	- [UPDATE] Debug messages are logged based on BuildConfig.DEBUG_LOG condition defined in gradle.build and will not be printed to log when a release build of the SDK is used.
	- [UPDATE] Improved Activity and Propositions lists to be sorted alphabetically.
	- [UPDATE] Improved nested fragment detection algorithm. 
	- [UPDATE] Added support for AppCompat switches. 
	- [UPDATE] Improved highlighting algorithm to not highlight elements which are not currently visible on screen. 
	- [BUGFIX] Fixed an issue with the region popover not always being displayed when selecting a region. 
	- [BUGFIX] Fixed an issue with the track cell disappearing after deleting the region tracking point. 
	- [BUGFIX] Fixed an issue where the floating action bar button could not be selected in some apps. 
	- [BUGFIX] Fixed null pointer exception which was occurring in certain apps where the view object was not available on load of the activity.
	- [BUGFIX] Fixed an issue where some cells where not being highlighted correctly in certain scenarios.
	- [BUGFIX] Resolved a memory leak in the class which provides the Admin mode highlighting.
	- [BUGFIX] Fixed an issues where multiple requests were being sent to ONE during scrolling of a list.
	- [BUGFIX] Fixed an issues where element items which hold the element path could be created twice within an interaction.
	- [BUGFIX] Fixed an issues with mini notification text being cropped when on 3 lines. 
	- [BUGFIX] Fixed path generation algorithm to correctly create element paths and remove them when no longer in use.  
	- [BUGFIX] Added a fix around how the SDK tracks view pager interaction which have not been initialised at load time. This fix prevents the client app from crashing. 
	- [BUGFIX] The SDK will no longer highlight views which are set as invisible or gone. 

Version 2.0.1
	- [NEW] Ability to ignore interactions from being tracked.
	- [NEW] Ability to retrieve the tid using getTid public method.
	- [NEW] Ability to retrieve the framework version using the frameworkVersion public method. 
	- [NEW] Ability to review debug logs only.
	- [UPDATE] The algorithm which identifies fragments in a view pager has been improved to better recognise fragments automatically.
	- [UPDATE] Elements which are added on screen at a later stage, are now also allocated a path automatically. 
	- [UPDATE] Added support for tracking and capturing data from custom ExpandableListView, ListView, GridView, AbsListView, Spinner, StackView and RecyclerView.
	- [UPDATE] Added support for capturing text from AppCompatEditText.
	- [UPDATE] Added support for capturing text from custom TextViews. 
	- [UPDATE] Added support for tracking NavigationMenuItemViews. 
	- [BUGFIX] Fixed crashed caused by pressing a Menu Item.  
	- [BUGFIX] Added exception around CoordinatorLayout, to avoid crashes.
	- [BUGFIX] Fixed issue with the poker chip disappearing in apps which use floating buttons or loading activities.
	- [BUGFIX] Added recursive check around interaction removal to ensure the correct interaction is highlighted given some are removed.
	- [BUGFIX] Fixed issue with invisible and/or hidden elements being highlighted.
	- [BUGFIX] Fixed crash which was occurring when pressing Menu Item buttons.
	- [BUGFIX] Fixed issues around the full screen notification not appearing on screen under certain circumstance.
	- [BUGFIX] Added fixes to the view pager interaction identification algorithm to allow business user to correctly select an interaction.
	- [BUGFIX] Fixed issue which prevented the whole interaction to be highlighted once the screen has been rotated.
	- [BUGFIX] Decreased full screen notification opacity.
	- [BUGFIX] Fixed inability to select some capture point elements. 
	- [BUGFIX] Fixed highlighting algorithm to enable highlighting of nested interaction.  
	- [BUGFIX] Fixed issue with the poker chip being displayed when the app is in the background. 
	- [BUGFIX] Fixed highlighting issues with layouts sitting on top of other layouts.
