Version 2.16.0
	- [NEW] Ability to capture text from a Button.
	- [NEW] Ability to track list items where the label matches the list item width and height.
	- [NEW] Add ability paste username and password when logging in to Admin mode. 
	- [UPDATE] We have updated how we store unsent response codes to ensure all response codes are sent to ONE.
	- [UPDATE] Updated the oauth library implementation to reduce the SDK package size. 
	- [UPDATE] Improved the mini notification implementation to support across all screen orientations and avoid a crash which was occurring on device rotation.
	- [UPDATE] Updated the one install and one reinstall implementations to not send interactions for apps that already have been installed and use an older version of the SDK.
	- [BUGFIX] Resolved an issue where an empty region name would sometimes be shown against interactions when running the SDK in Admin mode.
	- [BUGFIX] Resolved an issue where PUT requests were being sent twice when running the SDK in iOS 7.

Version 2.15.0
	- [NEW] Improve install/identity tracking to allow identity sync with web touchpoints programmatically.
	- [BUGFIX] Resolved an issues where sometimes requests were sent twice when tapping a collection or table view cell which was tracked.
	- [BUGFIX] Resolved an issue where a runtime request sometimes was sent twice when in Preview mode.
	- [BUGFIX] Resolved an issue where identity sync occurred when launching the app in Admin mode.
	- [BUGFIX] Resolved an issue where the username was sometimes cleared in Admin mode.
	- [BUGFIX] Resolved an issue where the one-tid was not always appended to requests.

Version 2.14.0
	- [NEW] Install tracking capability when using the Redirect Tracking API. 
    - [UPDATE] Updated the login email text field to use an email input.
    - [BUGFIX] Resolved an issue where the full screen optimization is presented incorrectly on top of a UIAlertController.
    - [BUGFIX] Resolved an issue where the neutral code was resent once the app was terminated and reopened by tapping on the notification.

Version 2.13.0
	- [NEW] Improved the push notification support to use alert base push in combination with background push. 
	- [NEW] Ability to whitelist links eligible for identity transfer.
	- [NEW] Ability to blacklist links not eligible for identity transfer.
	- [UPDATE] Updated the properties caching logic to stop re-sending invalid properties after 2 failed attempts.
	- [BUGFIX] Fixed an issue where UIControl tracking points were not sent to ONE in User mode. 
	- [BUGFIX] Fixed an issue where the SDK was incorrectly displaying an 'no regions found' alert in Admin mode for certain type of view controllers.
	- [BUGFIX] Fixed an issue where the navigation bar was not being recognised by the SDK when highlighting elements in Admin mode. 
	- [BUGFIX] Resolved an issue where the full screen notification was interfering with action sheets.
	- [BUGFIX] Resolved an issue where the UIAlertController element mapping was causing multiple elements to be mapped with the same id. 
	- [BUGFIX] Resolved an issue where the Admin popover UX was not behaving correctly when adding group tracking or capture points.
	- [BUGFIX] Fixed an issue where the Admin popover was reappearing on screen once an error occurred.  


Version 2.12.0
	- [NEW] Ability to programmatically retrieve a push token.
	- [NEW] Ability to open a url received in a ONE push notification message.
	- [NEW] Ability to automatically send response codes for a push message received from ONE.
	- [BUGFIX] Resolved an issue where business users were unable to select some elements using the Admin mode interface. 

Version 2.11.0
	- [NEW] Ability to enable push notifications and codelessly receive a push message from ONE. 
	- [BUGFIX] Resolved attributes list incompatibility with the new design time api.
	- [BUGFIX] Fixed an Admin mode crash which was occurring when refreshing proposition lists.
	- [BUGFIX] Fixed an issue where a user was able to navigate in Admin mode when the SDK was retrieving the design time context. 
	- [BUGFIX] Resolved an Admin mode issue where a user was not able to dismiss an alert when the poker chip was present on screen. 
	- [BUGFIX] Resolved an issue where interaction requests were not triggered automatically in some apps.
	- [BUGFIX] Added support for StackViews as part of the elements path, to ensure that 2 elements don’t end up having the same path.
	- [BUGFIX] Resolved an issue where tracking points were not sent to ONE in some apps. 
	- [BUGFIX] Resolved an issue where the Apply button in one of the Admin mode views was not presented correctly once an error has occurred. 
	- [BUGFIX] Resolved an issue where tracking and capture points were only triggered every second time in certain apps.  

Version 2.10.0
	- [NEW] Given that you declare a specific app group as part of your app the SDK can now share the anonymous identifier between apps in the same app group. 
	- [UPDATE] The SDK now stores the thunderhead anonymous identifier depending on the space to which an app belongs to.
	- [UPDATE] Added descriptive logs after every return statement. These are controlled using the SDK log levels.
	- [BUGFIX] Resolved an issue where the SDK could not automatically recognise SafariViewControllers as an interaction. 
	- [BUGFIX] Resolved a crash which was occurring whilst propositions where refreshed in Admin mode.
	- [BUGFIX] Resolved an issue where the SDK would get into an incorrect state if the user was to tap the screen whilst preview was in a loading state.  

Version 2.9.0
	- [NEW] Cross-channel and install tracking using SafariViewController in apps running on iOS 9+.
	- [NEW] Ability to automatically share the tid between apps from the same vendor on apps running on iOS 7, 8 and 9. 
	- [NEW] The SDK will also now track non-https/http links opened in an app automatically using the 'one-click' interaction. 
	- [UPDATE] Removed the mapViews public method from the SDK.
	- [UPDATE] Updated the Swift method names to match the Objective C method names using the NS_SWIFT_NAME macro. 
	- [UPDATE] Improved the ability to retrieve a response from an automatically triggered interaction call to allow registration of delegate on a "per-interaction basis”. Please see the latest integration document for further details. 
	- [UPDATE] Preview mode usability improvements. 
	- [UPDATE] Update the SDK to better handle UIControls which are used as touch callbacks.
	- [UPDATE] iOS 10: Added support for 'openURL:options:completionHandler:' in order for the SDK to automatically pass incoming properties to ONE.
	- [UPDATE] Updated the CollectionView delegation protocol.
	- [BUGFIX] Resolved an issue where Admin users were unable to track and capture web views which were added as subviews.
	- [BUGFIX] Resolved an issue where the full screen notifications would stop from being shown on screen. 
	- [BUGFIX] Fixed an issue where our collection view capture point data gathering algorithm was not sending data correctly for certain edge cases.
	- [BUGFIX] Fixed an issue where interaction were not always sent when going to Preview mode in some apps.
	- [BUGFIX] Resolved an issue where the Poker chip would not be shown on screen in certain apps when running in Admin mode.
	- [BUGFIX] Resolved an issue where the Admin mode popover wasn’t functioning as expected.
	- [BUGFIX] Added a fix to allow Admin users to select the last footer in a table view.
	- [BUGFIX] Resolved an issue where the navigation buttons in Admin mode would change depending on the app the SDK was integrated with.
	- [BUGFIX] Fixed an issue where regions were not always fully highlighted when inside UITabBarController.
	- [BUGFIX] Fixed an issue where the element path wasn’t properly built for image views with gesture recognizer that sat within a cell.
	- [BUGFIX] Resolved an issue where tracking points inside cells were not always correctly sent to ONE in Preview and User mode. 
	- [BUGFIX] Resolved an issue where WKWebView tracking points were not correctly triggered in some apps. 
	- [BUGFIX] Updated the interaction recognition algorithm to recognise MFMailComposeViewController, MFMessageComposeViewController and SLComposeViewController again.

Version 2.8.4
	- [NEW] Ability to send a push token to ONE. This feature simply exposes the ability to programmatically pass the push token to ONE and will become available as an engagement feature in future ONE releases.
	- [UPDATE] Support for identifying interactions across windows. 
	- [UPDATE] Added an update which allows Admin users to select any elements visible on screen and interactions if no element is found on tap.
	- [UPDATE] Updated the interaction recognition algorithms to ignore interactions which don't have trackable elements inside them and interactions which are not currently visible (hidden or alpha less than 0.1).
	- [UPDATE] Removed support for Safari View Controller’s 'initWithURL with configuration' to automatically send a 'one-click' interaction to ONE for all outbound links opened from an app. This was due to the method being removed by Apple from the last beta release.
	- [UPDATE] Removed support for Safari View Controller’s 'initWithURL with configuration' to automatically add one-tid parameter for identity transfer on all links opened using this method. This was due to the method being removed by Apple from the last beta release.	
	- [UPDATE] Updated the ONE SDK public method documentation. 
	- [BUGFIX] Resolved an issue where the SDK could not handle subclassed split view controllers using a similar name to the UISplitViewController.

Version 2.8.3
	- [UPDATE] Removed the need to pass error by reference when calling getURLWithOneTid.
	- [BUGFIX] Resolved an issue where the tid was not shown, in preview mode, even though a response was received.

Version 2.8.2
	- [NEW] Ability to automatically send a 'one-click' interaction to ONE for all outbound links opened from an app.
	- [UPDATE] Contained iOS 10 update - Added support for Safari View Controller’s 'initWithURL with configuration' to automatically send a 'one-click' interaction to ONE for all outbound links opened from an app.
	- [UPDATE] Contained iOS 10: Added support for Safari View Controller’s 'initWithURL with configuration' to automatically add one-tid parameter for identity transfer on all links opened using this method. 	
	- [UPDATE] Updated the ONE SDK public method documentation. 

Version 2.8.1
	- [BUGFIX] Resolved an issue where poker chip was not correctly displayed in apps which create their window programmatically.
	- [BUGFIX] Resolved an issue where the Admin mode highlighting disappeared after an alert was shown on screen.

Version 2.8.0
	- [NEW] Ability to filter attribute list in Admin mode.
	- [NEW] Support outgoing one tid parameter for identity transfer in WKWebViews.
	- [UPDATE] Improve the send interaction with properties method to fall back on the send interaction method if no properties are passed.
	- [BUGFIX] Fixed a UI bug in preview mode where releases were incorrectly aligned on the screen. 

Version 2.7.1
	- [UPDATE] Reverted the algorithm which places the Thunderhead Admin mode window above other application windows automatically.

Version 2.7.0
	- [NEW] Add support for CSRF headers to all design time APIs.
	- [NEW] Ability to enter username and password when using touch ID.
	- [NEW] Ability to enter preview mode on long press.
	- [NEW] Ability to store username and passwords in device keychain.
	- [NEW] Ability to see the TID in preview mode.
	- [NEW] Ability to share monitor URL.
	- [NEW] Ability to track and capture a WKWebView.
	- [UPDATE] Added an algorithm which places the Thunderhead Admin mode window above other application windows automatically should these want to sit above it.
	- [BUGFIX] Resolved an Admin mode crash which was occurring when editing a capture point. 
	- [BUGFIX] Resolved a crash which was occurring when searching for dynamic propositions and using the pull to refresh feature.
	- [BUGIFX] Resolved a crash which was occurring if the response delegate object was removed in callback method of an automatically triggered interaction.

Version 2.6.0
	- [NEW] Removed single customer key and added support for capturing into key attributes.
	- [NEW] Added support for UTF-8 in mobile assets.
	- [NEW] Added ability to distribute the SDK as an embedded framework.
	- [UPDATE] Updated the point count APIs to align with PC12 API changes. 
	- [UPDATE] The SDK is now storing the reachability object weakly.
	- [UPDATE] Improved automatic text capturing support for text fields, text views and search bars.
	- [UPDATE] Updated the ability to retrieve a response from an automatically triggered interaction call using delegate pattern implementation. 

Version 2.5.2
	- [BUGFIX] Resolved issue with html encoded characters not being displayed properly in the SDK. 

Version 2.5.1
	- [BUGFIX] Added CFBundleSupportedPlatforms to the Thunderhead bundle and set it as iPhoneOS. 

Version 2.5.0
	- [NEW] Ability to set a mini notification background colour.
	- [NEW] Ability to set a mini notification timer.
	- [NEW] Ability to set a mini notification text size and colour.
	- [NEW] Added support for flexible image width in mini notifications.
	- [NEW] Ability to get structure data.
	- [NEW] Ability to retrieve a response from an automatically triggered interaction call using a delegate pattern. 
	- [UPDATE] Updated manual interactions implementation to trigger known optimizations if blocks are not used.
	- [UPDATE] Eliminate the need in adding compiler flag -ObjC during SDK integration.
	- [UPDATE] Removed the use of the FBKVOController from the SDK. This implementation has been replaced by swizzling. ‘didMoveToWindow’, ‘setText’ and ‘setAttributedText’ will be swizzled as part of the automatic data capture.
	- [UPDATE] Updated the ‘one_tid’ parameter used as part of the automatic identity transfer to ‘one-tid’.
	- [UPDATE] Updated the ‘In the Works’ description copy text.
	- [BUGFIX] Resolved an issue where poker chip appeared on top of the login screen. 
	- [BUGFIX] Resolved an issue where the SDK could crash if too many mapping requests where being created at the same time. 

Version 2.4.1
	- [BUGFIX] Fixed an issue where user is in process of entering text into text field and premature request with captured text might be sent to ONE before user finishes entering.

Version 2.4.0
	- [NEW] Ability to track and capture data from repeating cells in Admin mode.
	- [NEW] Ability to send a response code programmatically.
	- [NEW] Ability to switch off automatic interaction detection in the SDK.
	- [NEW] Added support for automatic interception of incoming parameters.
 	- [NEW] Added support for automatic appending of a ‘one_tid’ parameter on all outgoing links to support identity transfer.
	- [UPDATE] Removed the need to add SDK dependencies manually and started fully supporting modules.
	- [BUGFIX] Resolved an issue where the app crashed when a user would navigate to Preview mode iOS7.
	- [BUGFIX] Fixed an issues where an app could not be exported due to a  bundle unspecified key in the Thunderhead SDK bundle. 
	- [BUGFIX] Fixed an issues where not all interaction requests contained device data.
	- [BUGFIX] Resolved an issue where a manually triggered interaction request for a different channel could contain an incorrect URI.
	- [BUGFIX] Resolved an issue where the popover was being displayed over the element.
	- [BUGFIX] Resolved an issue where the Admin popover showed the attribute name instead of hardcoded <Proposition set dynamically> when using a dynamic proposition.
	- [BUGFIX] Resolved an issue where the preview point counts was overlapped by status bar.

Version 2.3.0
	- [NEW] Extended the SDKs programmatic support to allow response retrieval, from manually triggered interactions.
	- [NEW] Added support for programmatically triggering interaction requests, for another space, from within a current mobile touchpoint. 
	- [UPDATE] Updated the UI for all key Admin mode screens.
	- [UPDATE] Updated Preview mode point counts UI.
	- [UPDATE] Updated Preview mode to align with new Tagger.
	- [UPDATE] Updated Edit mode highlighting to align with new Tagger.
	- [BUGFIX] Fixed an issue where the Preview mode poker chip would disappear when an alert was presented in iOS 7.

Version 2.2.0
	- [NEW] Ability to select attributes for dynamic propositions using the Admin mode interface. 
	- [NEW] Ability to track and capture data from repeating Table View cells and cell elements.
	- [NEW] Ability to track and capture data from repeating Collection View cells and cell elements.
	- [BUGFIX] Fixed an issue where the capture points where being sent twice for the same element. 

Version 2.1.6
	- [BUGFIX] Fixed an issue where the session was being invalidated where no regions could be found for a view controller.
	- [BUGFIX] Fixed an issue where a tracking point could be added to text field, search bar or text view.

Version 2.1.5
	- [UPDATE] Added bitcode support
	- [BUGFIX] Resolved an issue where passwords containing special characters weren’t parsed correctly by the network controller 

Version 2.1.4
	- [UPDATE] Updated the public method comments

Version 2.1.3
	- [UPDATE] Ensure captured data is not sent multiple times
	- [UPDATE] Improved implementation to support building the SDK under Xcode 6.x 
	- [BUGFIX] Changing region name causes the app crash
	- [BUGFIX] No region alert message causes the app crash
	- [BUGFIX] Requests are not always sent when popover appears
	- [BUGFIX] Non-existent capture point are triggered in User mode
	- [BUGFIX] Poker chip is active after dismissing No Region alert message
